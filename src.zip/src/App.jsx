﻿import React, { useState, useEffect } from 'react';


const randomId = () => Date.now().toString() + Math.random().toString(16).slice(2);


function DinoGame({ onRetry }) {
  const [dinoY, setDinoY] = useState(0);
  const [cactusX, setCactusX] = useState(100);
  const [gameOver, setGameOver] = useState(false);
  const [speed, setSpeed] = useState(0.8);
  const [passed, setPassed] = useState(0);


  useEffect(() => {
    if (gameOver) return;


    let lastTime = performance.now();
    const loop = (time) => {
      const delta = time - lastTime;
      lastTime = time;


      setCactusX((x) => {
        let nx = x - speed * (delta / 16);
        if (nx < -10) {
          nx = 100;
          setPassed((p) => {
            const next = p + 1;
            if (next % 3 === 0) setSpeed((s) => s + 0.2);
            return next;
          });
        }
        return nx;
      });


      if (cactusX < 20 && cactusX > 5 && dinoY < 25) {
        setGameOver(true);
      }


      if (!gameOver) requestAnimationFrame(loop);
    };


    const id = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(id);
  }, [gameOver, cactusX, speed, dinoY]);


  const jump = () => {
    if (dinoY !== 0) return;
    setDinoY(60);
    setTimeout(() => setDinoY(0), 400);
  };


  return (
    <div className="screen center">
      <div className="icon-circle">🛡️</div>
      <h1 className="title accent">SÉCURITÉ : CODE ERRONÉ</h1>


      <div className="game-area">
        <div className="dino" style={{ bottom: `${dinoY}px` }}>🐇</div>
        <div className="cactus" style={{ left: `${cactusX}%` }}>🚽</div>
        <div className="ground" />
      </div>


      {!gameOver ? (
        <button className="btn primary big" onClick={jump}>SAUTER</button>
      ) : (
        <button className="btn primary big" onClick={onRetry}>RÉESSAYER LE CODE</button>
      )}
    </div>
  );
}


function PinScreen({ onSuccess, onWrong }) {
  const [pin, setPin] = useState('');


  const pressKey = (num) => {
    const current = pin + num;
    if (current === '1234') {
      setPin('');
      onSuccess();
    } else if (current.length >= 4) {
      setPin('');
      onWrong();
    } else {
      setPin(current);
    }
  };


  return (
    <div className="screen center">
      <div className="icon-circle">🛡️</div>
      <h1 className="title">Entrez votre code</h1>


      <div className="pin-display">
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className={`dot ${pin.length > i ? 'dot-active' : ''}`} />
        ))}
      </div>


      <div className="numpad">
        {[1,2,3,4,5,6,7,8,9,0].map((n) => (
          <button key={n} className="key" onClick={() => pressKey(n.toString())}>{n}</button>
        ))}
      </div>
    </div>
  );
}


function Modal({ open, onClose, children }) {
  if (!open) return null;
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        {children}
      </div>
    </div>
  );
}


export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showGame, setShowGame] = useState(false);
  const [activeTab, setActiveTab] = useState('alters');


  const [alters, setAlters] = useState([]);
  const [switchLog, setSwitchLog] = useState([]);
  const [relations, setRelations] = useState([]);


  const [isAlterModalOpen, setAlterModalOpen] = useState(false);
  const [isLinkModalOpen, setLinkModalOpen] = useState(false);


  const [newAlter, setNewAlter] = useState({
    nom: '',
    role: '',
    age: '',
    genre: '',
    orientation: '',
    photo: null,
  });


  const [linkData, setLinkData] = useState({ from: '', to: '', type: 'Ami' });


  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setNewAlter((prev) => ({ ...prev, photo: reader.result }));
    };
    reader.readAsDataURL(file);
  };


  const handleSaveAlter = () => {
    if (!newAlter.nom.trim()) return;
    setAlters((prev) => [...prev, { ...newAlter, id: randomId() }]);
    setNewAlter({
      nom: '',
      role: '',
      age: '',
      genre: '',
      orientation: '',
      photo: null,
    });
    setAlterModalOpen(false);
  };


  const handleLogout = () => {
    setIsLoggedIn(false);
    setShowGame(false);
  };


  if (!isLoggedIn && showGame) {
    return <DinoGame onRetry={() => setShowGame(false)} />;
  }


  if (!isLoggedIn) {
    return (
      <PinScreen
        onSuccess={() => setIsLoggedIn(true)}
        onWrong={() => setShowGame(true)}
      />
    );
  }


  return (
    <div className="app">
      <header className="header">
        <div className="header-top">
          <h1 className="app-title">Système TDI</h1>
          <button className="icon-btn" onClick={handleLogout}>⏻</button>
        </div>


        <div className="tabs">
          <button className={`tab ${activeTab === 'alters' ? 'tab-active' : ''}`} onClick={() => setActiveTab('alters')}>Alters</button>
          <button className={`tab ${activeTab === 'journal' ? 'tab-active' : ''}`} onClick={() => setActiveTab('journal')}>Journal</button>
        </div>
      </header>


      <main className="content">
        {activeTab === 'alters' ? (
          <>
            {alters.map((a) => (
              <div key={a.id} className="card">
                <div className="avatar">
                  {a.photo ? <img src={a.photo} alt={a.nom} /> : <span className="avatar-icon">👤</span>}
                </div>


                <div className="card-main">
                  <div className="card-title">{a.nom}</div>
                  <div className="card-sub">{a.role || 'Rôle inconnu'}</div>
                  <div className="card-meta">
                    {a.age && <span>{a.age} ans</span>}
                    {a.genre && <span>{a.genre}</span>}
                    {a.orientation && <span>{a.orientation}</span>}
                  </div>
                </div>


                <button
                  className="btn small"
                  onClick={() =>
                    setSwitchLog((prev) => [
                      { id: randomId(), nom: a.nom, time: new Date().toLocaleTimeString() },
                      ...prev,
                    ])
                  }
                >
                  Switch
                </button>
              </div>
            ))}


            <h2 className="section-title">Liens du système</h2>


            {relations.map((rel) => (
              <div key={rel.id} className="link-card">
                <span className="link-icon">🔗</span>
                <span className="link-text">{rel.from} — {rel.type} — {rel.to}</span>
              </div>
            ))}


            <button className="btn outline full" onClick={() => setLinkModalOpen(true)}>Créer un lien</button>
          </>
        ) : (
          <>
            {switchLog.length === 0 && <p className="empty-text">Aucun switch enregistré pour l’instant.</p>}
            {switchLog.map((l) => (
              <div key={l.id} className="log-card">
                <span className="log-icon">⏱️</span>
                <span className="log-text"><strong>{l.nom}</strong> au front à {l.time}</span>
              </div>
            ))}
          </>
        )}
      </main>


      <button className="fab" onClick={() => setAlterModalOpen(true)}>+</button>


      <Modal open={isAlterModalOpen} onClose={() => setAlterModalOpen(false)}>
        <div className="modal-header">
          <h2>Nouvel Alter</h2>
          <button className="icon-btn" onClick={() => setAlterModalOpen(false)}>✕</button>
        </div>


        <div className="modal-body">
          <input className="input" placeholder="Nom" value={newAlter.nom} onChange={(e) => setNewAlter((p) => ({ ...p, nom: e.target.value }))} />
          <input className="input" placeholder="Âge" value={newAlter.age} onChange={(e) => setNewAlter((p) => ({ ...p, age: e.target.value }))} />
          <input className="input" placeholder="Rôle" value={newAlter.role} onChange={(e) => setNewAlter((p) => ({ ...p, role: e.target.value }))} />
          <input className="input" placeholder="Genre" value={newAlter.genre} onChange={(e) => setNewAlter((p) => ({ ...p, genre: e.target.value }))} />
          <input className="input" placeholder="Orientation" value={newAlter.orientation} onChange={(e) => setNewAlter((p) => ({ ...p, orientation: e.target.value }))} />


          <label className="file-label">
            <span>Ajouter une photo</span>
            <input type="file" accept="image/*" onChange={handleFileChange} style={{ display: 'none' }} />
          </label>


          {newAlter.photo && (
            <div className="preview">
              <img src={newAlter.photo} alt="Prévisualisation" />
            </div>
          )}


          <button className="btn primary full" onClick={handleSaveAlter}>ENREGISTRER</button>
        </div>
      </Modal>


      <Modal open={isLinkModalOpen} onClose={() => setLinkModalOpen(false)}>
        <div className="modal-header">
          <h2>Lier deux alters</h2>
          <button className="icon-btn" onClick={() => setLinkModalOpen(false)}>✕</button>
        </div>


        <div className="modal-body">
          <input className="input" placeholder="De l'alter..." value={linkData.from} onChange={(e) => setLinkData((p) => ({ ...p, from: e.target.value }))} />
          <input className="input" placeholder="Vers l'alter..." value={linkData.to} onChange={(e) => setLinkData((p) => ({ ...p, to: e.target.value }))} />
          <input className="input" placeholder="Relation" value={linkData.type} onChange={(e) => setLinkData((p) => ({ ...p, type: e.target.value }))} />


          <button
            className="btn primary full"
            onClick={() => {
              if (!linkData.from || !linkData.to) return;
              setRelations((prev) => [...prev, { ...linkData, id: randomId() }]);
              setLinkData({ from: '', to: '', type: 'Ami' });
              setLinkModalOpen(false);
            }}
          >
            LIER
          </button>
        </div>
      </Modal>
    </div>
  );
}